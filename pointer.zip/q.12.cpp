#include<iostream>
using namespace std;
int main(){
	int v =10;
	int *p1,*p2;
	p1 = &v;
	p2 = p1 + 5;
	cout<<"(p2-p1) :"<<(p2-p1)<<endl;
	return 0;
}
