 #include<iostream>
 using namespace std;
 int main(){
 	int A[5] ={5,8,6,9,10};
	int*p,*q;
	p=&A[0];
	q=&A [3];
	
	p--;
	return 0;
}
 
