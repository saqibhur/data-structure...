//changing value pointed by pointers
#include<iostream>
using namespace std;
int main(){
	
	int x=5;
	int* pointx;
	pointx = &x;
	*pointx=3;
	cout<< x <<endl;

	return 0;

}
