#include<iostream>
using namespace std;

int main()
{
   int *p;
   int arr[5] = {10, 20, 30, 40, 50};

   p = arr;

   cout<<"p = "<<*p;
   cout<<"\narr[0] = "<<arr[0];

   cout<<endl;
   return 0;
}

