//pointer variable
#include<iostream>
using namespace std;
int main(){
	int*p ,x =50;
	p =&x;
	cout<<"value of x is:"<<*p;
	return 0;
}
