#include<iostream>
using namespace std;
int main(){
	int a=3;
	int* p;
	p =&a;
	cout<<"the address of a is "<<&a<<endl;
	cout<<"the address of a is "<<p<<endl;
	cout<<"the value at address p is "<<*p<<endl;

	return 0;

}
