#include<iostream>
using namespace std;
int main(){
	void *p;
	float f = 2.3f;
	p = &f;
	cout<<&f<<endl;
	cout<<p<<endl;
	
	return 0;
}
