#include <iostream>
using namespace std;
int main() {
    int *ptr;  // Integer pointer declaration
    int arr[] = {1, 1, 2, 3, 4};

    cout << "The Traversing of array: ";

    ptr = arr;
    for (int i = 0; i < 4; i++) {
        cout << *ptr <<endl;
        // ++ moves the pointer to next int position
        ptr++;
    }

    return 0;
}



